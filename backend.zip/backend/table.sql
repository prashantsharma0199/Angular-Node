create table student(
  studname varchar(255),
  rollnum int primary key,
  dob date,
  score int
);

create table teacher(
  tname varchar(255),
  emailId varchar(255) primary key,
  password varchar(255)
);
